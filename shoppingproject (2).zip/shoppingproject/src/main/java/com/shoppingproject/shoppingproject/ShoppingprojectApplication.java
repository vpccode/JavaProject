package com.shoppingproject.shoppingproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingprojectApplication.class, args);
		System.out.println("********************************Hello***********************");
		System.out.println("********************************Hello***********************");
		System.out.println("********************************Hello***********************");
		System.out.println("********************************Hello***********************");
	}

}
